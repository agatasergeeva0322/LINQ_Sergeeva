﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;

namespace algoritm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<Person> people = new List<Person>();
            string file = "file2.txt";
            if (!File.Exists(file))
            {
                MessageBox.Show("Файл не найден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                label1.Text += $"\n\n";
                string[] lines = File.ReadAllLines(file);
                Person human = new Person("", "", "", 0, 0);
                foreach (string line in lines)
                {
                    
                    string[] chelovek = line.Split(' ');
                    string lastname = chelovek[0];
                    human.set_lastname(lastname);
                    string name = chelovek[1];
                    human.set_name(name);
                    string otfather = chelovek[2];
                    human.set_otfather(otfather);
                    int age = Convert.ToInt32(chelovek[3]);
                    human.set_age(age);
                    double weidth = Convert.ToDouble(chelovek[4]);
                    human.set_weidth(weidth);
                    label1.Text += $"{human.get_lastname()} {human.get_name()} {human.get_otfather()} {human.get_age()} {human.get_weidth()}\n";
                    people.Add(new Person(lastname, name,otfather, age, weidth));
                }

                var young = from p in people
                            where Convert.ToInt32(p.get_age()) < 40
                            select p;
                label2.Text += $"\n\n";
                foreach (var a in young)
                {
                    label2.Text += $"ФИО: {a.get_lastname()} {a.get_name()} {a.get_otfather()}\nВозраст: {a.get_age()}\nВес: {a.get_weidth()}\n\n\n";
                }
            }
        }
    }
}
